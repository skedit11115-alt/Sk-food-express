let products=[
{id:1,name:"Classic Cheese Burger",cat:"Burgers",price:149,desc:"Juicy patty, melted cheese and fresh crunch.",img:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700&auto=format&fit=crop&q=80"},
{id:2,name:"Margherita Pizza",cat:"Pizza",price:229,desc:"A timeless favourite with cheese and herbs.",img:"https://images.unsplash.com/photo-1513104890138-7c749659a591?w=700&auto=format&fit=crop&q=80"},
{id:3,name:"Chicken Biryani",cat:"Indian",price:199,desc:"Fragrant rice with a delicious spice blend.",img:"https://images.unsplash.com/photo-1563379091339-03246963d96c?w=700&auto=format&fit=crop&q=80"},
{id:4,name:"Paneer Butter Masala",cat:"Indian",price:179,desc:"Creamy tomato gravy with soft paneer.",img:"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=700&auto=format&fit=crop&q=80"},
{id:5,name:"Veg Hakka Noodles",cat:"Chinese",price:139,desc:"Wok-tossed noodles with crisp vegetables.",img:"https://images.unsplash.com/photo-1585032226651-759b368d7246?w=700&auto=format&fit=crop&q=80"},
{id:6,name:"Chocolate Cake",cat:"Desserts",price:129,desc:"A rich, sweet treat to finish your meal.",img:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=700&auto=format&fit=crop&q=80"}
];
const defaultProducts=JSON.parse(JSON.stringify(products));
try {
 const savedMenu=JSON.parse(localStorage.getItem("skFoodMenu")||"null");
 if(Array.isArray(savedMenu)) {
  const defaults=new Map(products.map(item=>[item.id,item]));
  products=savedMenu.filter(item=>item&&typeof item==="object").map((item,index)=>{
   const fallback=defaults.get(item.id)||{};
   const rawPrice=Number(item.price);
   return {
    id:Number.isFinite(Number(item.id))?Number(item.id):Date.now()+index,
    name:String(item.name||fallback.name||"Food item"),
    cat:String(item.cat||fallback.cat||"Other"),
    price:Number.isFinite(rawPrice)&&rawPrice>=0?rawPrice:(Number(fallback.price)||0),
    desc:String(item.desc||fallback.desc||""),
    img:String(item.img||fallback.img||"")
   };
  });
 }
} catch(e) { products=JSON.parse(JSON.stringify(products)); }
let cart=[],category="All";
const saveMenu=()=>localStorage.setItem("skFoodMenu",JSON.stringify(products));
let managerUnlocked=false;
const DEFAULT_MANAGER_PIN="2468";
// Keep all displayed and calculated prices numeric; include a space after ₹
// so Android font fallback cannot visually merge the currency sign with the first digit.
const numericPrice=value=>{
 const amount=Number(value);
 return Number.isFinite(amount)&&amount>=0?Math.round((amount+Number.EPSILON)*100)/100:0;
};
// Calculate in paise (whole integers) to avoid floating-point rounding errors.
const toPaise=value=>Math.round(numericPrice(value)*100);
const moneyFromPaise=paise=>"₹ "+(Math.max(0,Math.round(Number(paise)||0))/100).toLocaleString("en-IN",{minimumFractionDigits:0,maximumFractionDigits:2});
const money=value=>moneyFromPaise(toPaise(value));
const safeQty=value=>Math.max(0,Math.floor(Number(value)||0));
const cartSubtotalPaise=()=>cart.reduce((sum,item)=>sum+toPaise(item.price)*safeQty(item.qty),0);
function renderMenu(){
 const q=document.getElementById("search").value.toLowerCase().trim();
 const list=products.filter(p=>(category==="All"||p.cat===category)&&(p.name.toLowerCase().includes(q)||p.cat.toLowerCase().includes(q)));
 document.getElementById("food-grid").innerHTML=list.map(p=>`<article class="food-card"><img src="${p.img}" alt="${p.name}" loading="lazy"><div class="food-info"><div class="food-bottom"><h3>${p.name}</h3><span class="category">${p.cat}</span></div><p>${p.desc}</p><div class="food-bottom"><span class="price">${money(p.price)}</span><button class="add" onclick="add(${p.id})">+ Add</button></div></div></article>`).join("");
 document.getElementById("empty").hidden=list.length>0;
}
function add(id){const p=products.find(x=>x.id===id);if(!p)return;const found=cart.find(x=>x.id===id);if(found)found.qty++;else cart.push({...p,price:numericPrice(p.price),qty:1});renderCart();toast(p.name+" added to cart");}
function change(id,delta){const p=cart.find(x=>x.id===id);if(!p)return;p.qty+=delta;if(p.qty<1)cart=cart.filter(x=>x.id!==id);renderCart();}
function removeItem(id){cart=cart.filter(x=>x.id!==id);renderCart();}
function renderCart(){
 const count=cart.reduce((sum,item)=>sum+safeQty(item.qty),0);
 const subtotalPaise=cartSubtotalPaise();
 const deliveryPaise=count>0?3000:0;
 document.getElementById("cart-count").textContent=count;
 document.getElementById("subtotal").textContent=moneyFromPaise(subtotalPaise);
 document.getElementById("delivery").textContent=moneyFromPaise(deliveryPaise);
 document.getElementById("total").textContent=moneyFromPaise(subtotalPaise+deliveryPaise);
 document.getElementById("cart-items").innerHTML=cart.length?cart.map(p=>`<div class="cart-row"><div><b>${p.name}</b><small>${money(p.price)} each</small></div><div class="qty"><button onclick="change(${p.id},-1)">−</button>${p.qty}<button onclick="change(${p.id},1)">+</button></div><button class="remove" onclick="removeItem(${p.id})">Remove</button></div>`).join(""):"Your cart is empty. Add a favourite dish to get started.";
 document.getElementById("checkout").disabled=!count;
}
function toast(msg){const el=document.getElementById("toast");el.textContent=msg;el.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove("show"),1700);}
document.querySelectorAll("[data-cat]").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll("[data-cat]").forEach(b=>b.classList.remove("active"));btn.classList.add("active");category=btn.dataset.cat;renderMenu();}));
document.getElementById("search").addEventListener("input",renderMenu);
document.getElementById("checkout").addEventListener("click",()=>{document.getElementById("checkout-form").hidden=false;document.getElementById("checkout-form").scrollIntoView({behavior:"smooth"});});
document.getElementById("checkout-form").addEventListener("submit",e=>{
 e.preventDefault();
 if(!cart.length)return;
 const data=new FormData(e.target);
 const name=data.get("name").trim();
 const phone=data.get("phone").trim();
 const address=data.get("address").trim();
 const subtotalPaise=cartSubtotalPaise();
 const deliveryPaise=cart.length?3000:0;
 const totalPaise=subtotalPaise+deliveryPaise;
 const order="SK"+Math.floor(10000+Math.random()*90000);
 const items=cart.map(p=>`${p.name} x ${safeQty(p.qty)} = ${moneyFromPaise(toPaise(p.price)*safeQty(p.qty))}`).join("\n");
 const message=`NEW ORDER - SK FOOD EXPRESS\nOrder: ${order}\nCustomer: ${name}\nPhone: ${phone}\nAddress: ${address}\n\nItems:\n${items}\n\nSubtotal: ${moneyFromPaise(subtotalPaise)}\nDelivery: ${moneyFromPaise(deliveryPaise)}\nTOTAL: ${moneyFromPaise(totalPaise)}`;
 const smsUrl="sms:9487278667?body="+encodeURIComponent(message);
 const box=document.getElementById("success");
 box.hidden=false;
 box.textContent=`Order ${order} is ready. Your SMS app will open with the order details for the manager. Please tap Send in your messaging app to submit it.`;
 box.scrollIntoView({behavior:"smooth"});
 window.location.href=smsUrl;
});
document.getElementById("menu-toggle").addEventListener("click",()=>document.getElementById("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));
document.getElementById("year").textContent=new Date().getFullYear();renderMenu();renderCart();

// Manager controls
const managerPanel=document.getElementById("manager-panel");
document.getElementById("manager-open").addEventListener("click",()=>{managerPanel.hidden=false;managerPanel.scrollIntoView({behavior:"smooth"});});
document.getElementById("manager-close").addEventListener("click",()=>{managerPanel.hidden=true;});
document.getElementById("manager-login").addEventListener("submit",e=>{e.preventDefault();let pin=localStorage.getItem("skFoodManagerPin")||DEFAULT_MANAGER_PIN;if(document.getElementById("manager-pin").value!==pin){alert("Incorrect manager PIN. Please try again.");return;}managerUnlocked=true;document.getElementById("manager-login").hidden=true;document.getElementById("manager-tools").hidden=false;renderManagerList();});
function renderManagerList(){document.getElementById("manager-list").innerHTML=products.map(p=>`<div class="manager-item"><div><b>${p.name}</b><small>${p.cat} · ${money(p.price)}</small></div><button class="remove" onclick="managerEdit(${p.id})">Edit</button><button class="remove" onclick="managerDelete(${p.id})">Delete</button></div>`).join("")||"No menu items yet.";}
function managerEdit(id){if(!managerUnlocked)return;const p=products.find(x=>x.id===id);if(!p)return;const name=prompt("Food item name:",p.name);if(name===null)return;const priceInput=prompt("Price in ₹:",p.price);if(priceInput===null)return;const price=Number(priceInput);if(!name.trim()||!Number.isFinite(price)||price<1){alert("Enter a valid name and price.");return;}p.name=name.trim();p.price=numericPrice(price);saveMenu();renderMenu();renderManagerList();}
function managerDelete(id){if(!managerUnlocked)return;if(!confirm("Delete this food item from the menu?"))return;products=products.filter(p=>p.id!==id);cart=cart.filter(p=>p.id!==id);saveMenu();renderMenu();renderCart();renderManagerList();}
document.getElementById("product-form").addEventListener("submit",e=>{e.preventDefault();if(!managerUnlocked)return;const name=document.getElementById("product-name").value.trim(),cat=document.getElementById("product-category").value.trim(),price=Number(document.getElementById("product-price").value),desc=document.getElementById("product-desc").value.trim(),img=document.getElementById("product-img").value.trim()||"https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=700&auto=format&fit=crop&q=80";if(!name||!cat||!desc||!Number.isFinite(price)||price<1){alert("Please enter valid item details.");return;}products.push({id:Date.now(),name,cat,price,desc,img});saveMenu();renderMenu();renderManagerList();e.target.reset();toast("Food item added");});
document.getElementById("change-pin").addEventListener("click",()=>{if(!managerUnlocked)return;const next=prompt("Set a new manager PIN (at least 4 digits):");if(next===null)return;if(!/^\d{4,10}$/.test(next)){alert("PIN must be 4 to 10 digits.");return;}localStorage.setItem("skFoodManagerPin",next);alert("Manager PIN updated on this device.");});

// Reset all locally saved website data
document.getElementById("reset-database").addEventListener("click",()=>{
 if(!managerUnlocked)return;
 if(!confirm("Reset ALL website data on this device? This restores the original menu and default manager PIN, and clears the cart and saved menu changes."))return;
 localStorage.removeItem("skFoodMenu");
 localStorage.removeItem("skFoodManagerPin");
 products=JSON.parse(JSON.stringify(defaultProducts));
 cart=[]; category="All";
 document.querySelectorAll("[data-cat]").forEach(b=>b.classList.toggle("active",b.dataset.cat==="All"));
 document.getElementById("search").value="";
 document.getElementById("manager-pin").value="";
 renderMenu(); renderCart(); renderManagerList();
 toast("All saved data reset. Default menu and PIN restored.");
});


// Reset only the menu to the original food items and prices; keep manager PIN and other data.
document.getElementById("reset-menu").addEventListener("click",()=>{
 if(!managerUnlocked)return;
 if(!confirm("Restore the original food items and prices? Your manager PIN will stay unchanged."))return;
 products=JSON.parse(JSON.stringify(defaultProducts));
 saveMenu();
 renderMenu();
 renderManagerList();
 toast("Original menu and prices restored.");
});
